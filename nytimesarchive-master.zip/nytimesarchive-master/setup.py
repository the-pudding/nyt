from distutils.core import setup

setup(name='nytimesarchive',
      version='0.1',
      description='Python wrapper for the New York Times Archive API',
      author='David Cox',
      author_email='davidcox143@gmail.com',
      url='https://github.com/davidcox143/nytimesarchive',
     )
